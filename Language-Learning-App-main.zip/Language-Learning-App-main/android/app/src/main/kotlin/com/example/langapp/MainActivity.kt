package com.example.langapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
